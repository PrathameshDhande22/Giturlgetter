from .extractor import main

def run():
    main()
